set ws=WScript.CreateObject("WScript.Shell")
ws.Run "Main.bat",0