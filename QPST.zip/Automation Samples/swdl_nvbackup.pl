###############################################################################
# (c) Qualcomm, Inc. 2006
#
# NV Backup
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Cannot start $prod_id";
}

if (defined $qpst)
{
  $qpst_version = $qpst->AppVersion;
  print "Using QPST $qpst_version\n";

  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "Selected port $port_name\n";

    $port_status = $port->PhoneStatus;
    $phone_status = $phone_status_list{$port_status};

    if ($phone_status eq "phoneStatusReady")
    {
      # get softwaredownload object
      $software_download = $port->SoftwareDownload;
      
      if (defined $software_download)
      {
        # set up vars for various operations
        $nv_backup_path = "\\Program Files\\QPST\\bin\\NV Backup\\test.qcn";
        $spc = "000000";
      
        print "Perform NV backup on $port_name to $nv_backup_path using SPC $spc? (y/n) ";
        $reply = <STDIN>;
        chomp($reply);

        if ($reply =~ /^(y(|e(|s)))\b/i)    # y, ye, yes
        {
          # perform nv backup
          $software_download->BackupNV($nv_backup_path, $spc);
          
          $error = 0 + Win32::OLE->LastError();
          
          if ($error)
          {
            print "Encountered an error while calling the function\n";
          }
          else
          {
            # get error message -- will be empty if op was successful
            $error_message = $software_download->GetErrorMessage();
        
            # display completion status
            if ($error_message eq "")
            {
              print "NV Backup completed successfully.\n";
            }
            else
            {
              print "NV Backup failed with message: $error_message.\n";
            }
          }
        }

        undef $software_download;
      }
      else
      {
        print "Unable to connect to Software Download component\n";
      }
    }
    else
    {
      print "Phone in bad state: $phone_status\n";
    }

    undef $port;
  }
  else
  {
    print "Port not available\n";
  }

  undef $qpst;
}
else
{
  print "QPST not available\n";
}

