###############################################################################
# (c) Qualcomm, Inc. 2006-2009
#
# Enumerate the files in a directory and print their properties.
#
# Demonstrate use of RecursiveDirList, Count, EntryName, EntryType, Mode,
#  EntrySize, AccTime, ModTime, ChgTime
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;
use efs_error;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  %file_type_list = qw (
    0 file
    1 dir
    2 link);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "port $port_name\n";

    $port_status = $port->PhoneStatus;

    if ($phone_status_list{$port_status} eq "phoneStatusReady")
    {
      $efsPrimary = $port->EFS;		# same as GetEFSSubsystem( 19 )
      $efsAlternate = $port->GetEFSSubsystem( 62 );

      if (defined $efsPrimary and defined $efsAlternate)
      {
        $version = $efsPrimary->EFSVersion;
        print "EFS version $version\n";

        if ($version == 2)
        {

          print "EFS path ? ";
          $efs_path = <STDIN>;
          chomp($efs_path);

          # the script will iterate the primary file subsystem id, then the 'alternate'
          @file_subsystems = ( $efsPrimary,   # primary
                               $efsAlternate   # alternate
                             );
          if ($efs_path ne "")
          {
            foreach $fs (@file_subsystems)
            {
               $fssid = $fs->{FileSubsystemId};
               print "** File subsystem = $fssid\n";
               
               $dir_iter = $fs->RecursiveDirList($efs_path);

               $error = Win32::OLE->LastError();

               if (($error + 0) != 0)
               {
                 print "error in path $efs_path\n";
                 print_error($error, $efs);
               }

               if (defined $dir_iter)
               {
                 $count = $dir_iter->Count;
                 print "count $count\n";

                 for ($i = 0 ; $i < $count ; ++$i)
                 {
                   $name = $dir_iter->EntryName($i);
                   #print "name $name\n";

                   $ftype = $file_type_list{$dir_iter->EntryType($i)};
                   #print " type $ftype\n";

                   print "$name ($ftype)\n";

                   #$fmode = $dir_iter->Mode($i);
                   #print " mode $fmode\n";

                   #$fsize = $dir_iter->EntrySize($i);
                   #print " size $fsize\n";

                   #$atime = $dir_iter->AccTime($i);  # Last access time
                   #print " acc time $atime\n";

                   #$mtime = $dir_iter->ModTime($i);  # Modification time
                   #print " mod time $mtime\n";

                   #$ctime = $dir_iter->ChgTime($i);  # Status change time
                   #print " chg time $ctime\n";
                 }

                 undef $dir_iter;
               }
               else
               {
                 print "No directory iterator\n";
               }
	       undef $fs;
            }
          }
        }
        else
        {
          print "Incompatible EFS version\n";
        }
      }
      else
      {
        print "No EFS interface for this port\n";
      }

      undef $efsPrimary;
      undef $efsAlternate;
    }
    else
    {
      print "Phone not ready\n";
    }
  }
  else
  {
    print "Port not available\n";
  }

  undef $port;
}
else
{
  print "QPST not available\n";
}

undef $qpst;

