import pythoncom
import win32com.client
import sys
import os


phone_mode_list = {}
phone_mode_list[0] = "no_phone"
phone_mode_list[2] = "download"
phone_mode_list[3] = "diag_online"
phone_mode_list[4] = "diag_offline"
phone_mode_list[6] = "stream_download"
phone_mode_list[12] = "sahara"

hello_rsp_list = {}
hello_rsp_list[0] = "default"
hello_rsp_list[1] = "dump_not_download"
hello_rsp_list[2] = "download_not_dump"
hello_rsp_list[3] = "wait_for_selection"

try:
    qpst = win32com.client.GetActiveObject(Class="QPSTAtmnServer.Application")  
    if qpst:
        print("QPSTAtmnServer.Application get ready")
except:
    qpst = win32com.client.Dispatch("QPSTAtmnServer.Application")
    
if not qpst:
    print("QPSTAtmnServer.Application not installed or cannot start")
    sys.exit()
        
 
qpst._FlagAsMethod("GetPort")

port_name = input("Enter COM port name:\n")  
port = qpst.GetPort(port_name)

if not port:
    print("The port " + port_name + " not found")
    print("Exit...")
    qpst.Quit()
 


isFirst = True
while True:
    if not isFirst:
        print("\n" + port_name)
    isFirst = False    
    
    MSMSerialNumber = ""
    for x in range(5):
        MSMSerialNumber = port.QCSerialNumber
        if MSMSerialNumber == "":
            sleep(1)
            continue
        break
    print("==> MSM serial number:  " + MSMSerialNumber)  
    
    init_enable = port.EnableSaharaSupport
    if init_enable:
        print("==> Sahara support is enabled")
    else:
        print("==> Sahara support is disabled")
        
    hello_rsp = port.SaharaHelloRsp
    hello_action = hello_rsp_list[hello_rsp]
    print("==> Response to Hello is:  " + hello_action)

    phone_mode = port.PhoneMode
    phone_mode_name = phone_mode_list[phone_mode]
    print("==> Phone mode is :  " + phone_mode_name)    

    init_dumptime = port.EnableDumpTimeStamp
    if init_dumptime:
        print("==> Dump timestamp is enabled")
    else:
        print("==> Dump timestamp is disabled")
        
    init_autoReset = port.EnableSaharaAutoReset
    if init_autoReset:
        print("==> Dump auto reset is enabled")
    else:
        print("==> Dump auto reset is disabled")    

    # Display menu
    mode_check = ""
    if 12 != phone_mode:
        mode_check = "(phone in wrong mode!)"  
    
    crash_check = mode_check    
    init_event = port.LastSaharaEvent
    if 19 != init_event and 20 != init_event:
        crash_check = "(no crash in progress!)"
        
    print("0:  get MSM serial number")
    print("1:  enable/disable Sahara support")
    print("2:  set download XML path and 1-time flag")
    print("3:  get XML path/flag")
    print("4:  set memory dump folder")
    print("5:  get memory dump folder")
    print("6:  get last Sahara event")
    print("7:  enable/disable dump timestamp")
    print("8:  enable/disable dump auto reset")
    print("9:  send Sahara reset command " + mode_check)
    print("10: abort crash dump and reset device " + crash_check)
    print("11: set Hello response action")
    print("12: get last memory dump path")
    print("13: sahara continue")
    print("\n")
    op_selected = input("Enter selection: ")
    op_selected.strip()

    if op_selected == "0":
        while True:
            MSMSerialNumber = port.QCSerialNumber
            if MSMSerialNumber == "":
                print("Finding MSM serial number...")
                sleep(1)
            else:
                print("MSM serial number is " + MSMSerialNumber)
                break    
        
    elif op_selected == "1":
        input_sel = input("Enable Sahara support (yes/no)?: ")
        input_sel = input_sel.strip()
        input_sel = input_sel.lower()
        enab_sahara = None   
        if input_sel == "y" or input_sel == "ye" or input_sel == "yes":
            enab_sahara = 1
        elif input_sel == "n" or input_sel == "no":
            enab_sahara = 0
        else:   
            pass    
        if enab_sahara == None:
            print("setting not changed\n")
        else:        
            port.EnableSaharaSupport = enab_sahara   
        
    elif op_selected == "2":
        xmlPath = input("Enter XML path: ")
        xmlPath = xmlPath.strip()
        oneTime = input("Use XML one time(yes/no)?: ")
        oneTime = oneTime.strip()    
        oneTime = oneTime.lower() 
        
        if oneTime == "y" or oneTime == "ye" or oneTime == "yes":
            port.SaharaConfigXML(xmlPath, 1)    
        else:   
            port.SaharaConfigXML(xmlPath, 0)
        
    elif op_selected == "3":
        xmlPath = port.XmlPath
        oneTime = port.PathOneTimeUse
        print("XML path = " + xmlPath)
        print("oneTime = %d"%oneTime)
        
    elif op_selected == "4":
        dumpPath = input("Enter memory dump folder path: ")
        dumpPath = dumpPath.strip()
        port.MemoryDumpFolder = dumpPath
        
    elif op_selected == "5":
        folder = port.MemoryDumpFolder
        print("memory debug folder = " + folder)
        
    elif op_selected == "6":
        last_event = port.LastSaharaEvent
        print("last Sahara event = %s"%last_event)        
        
    elif op_selected == "7":
        input_sel = input("Enable dump timestamp (yes/no)?: ")
        input_sel = input_sel.strip()
        input_sel = input_sel.lower()
        reply = None   
        if input_sel == "y" or input_sel == "ye" or input_sel == "yes":
            reply = 1
        elif input_sel == "n" or input_sel == "no":
            reply = 0
        else:   
            pass  
        
        if reply == None:
            print("setting not changed\n")
        else: 
            print(" (reply = %d)"%reply)
            port.EnableDumpTimeStamp = reply 
        print("Reset EnableDumpTimeStamp (result = %d)"%port.EnableDumpTimeStamp)
        
    elif op_selected == "8":
        input_sel = input("Enable dump auto reset (yes/no)?: ")
        input_sel = input_sel.strip()
        input_sel = input_sel.lower()
        reply = None   
        if input_sel == "y" or input_sel == "ye" or input_sel == "yes":
            reply = 1
        elif input_sel == "n" or input_sel == "no":
            reply = 0
        else:   
            pass    
        if reply == None:
            print("setting not changed\n")
        else:        
            port.EnableSaharaAutoReset = reply
            
    elif op_selected == "9":
        result = False
        try:
            result = port.SendSaharaResetCmd()
        except pythoncom.com_error as error:
            print("Failed: Exception occurred.")
            print (vars(error))
            qpst.Quit()    
            break
                    
        if result == True:
            print("Reset succeeded")
        else:
            print("Reset failed")
        
    elif op_selected == "10":
        result = False
        try:
            result = port.SaharaAbortDumpAndReset()
        except pythoncom.com_error as error:
            print("Failed: Exception occurred.")
            print (vars(error))
            qpst.Quit()    
            break
                    
        if result == True:
            print("Abort+Reset succeeded")
        else:
            print("Abort+Reset failed")      
            
    elif op_selected == "11":
        print("Upon receiving Sahara Hello...")
        print("0 = perform requested action")
        print("1 = if a download request, perform a RAM dump instead")
        print("2 = if a RAM dump request, perform a download instead")
        print("3 = do nothing until one of the other response modes is selected")

        input_num = input("Enter action value:")
        input_num = input_num.strip()
        port.SaharaHelloRsp = int(input_num)
        
    elif op_selected == "12":
        dump_path = port.LastMemoryDumpPath
        print("get last memory dump path = " + dump_path) 
        
    elif op_selected == "13":        
        try:
            port.SaharaContinue()
        except pythoncom.com_error as error:
            print("Failed: Exception occurred.")
            print (vars(error))
            qpst.Quit()    
            break
        
        print("The SaharaContinue has been executed.") 
        
    else:
        break

qpst.Quit()
print("Done!\n")


