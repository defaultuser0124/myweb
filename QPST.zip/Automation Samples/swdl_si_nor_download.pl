###############################################################################
# (c) Qualcomm, Inc. 2006
#
# Single-image software download (NOR flash).
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Cannot start $prod_id";
}

if (defined $qpst)
{
  $qpst_version = $qpst->AppVersion;
  print "Using QPST $qpst_version\n";

  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "Selected port $port_name\n";

    $port_status = $port->PhoneStatus;
    $phone_status = $phone_status_list{$port_status};

    if ($phone_status eq "phoneStatusReady")
    {
      # get softwaredownload object
      $software_download = $port->SoftwareDownload;
      
      if (defined $software_download)
      {
        # set up vars for various operations
        $phone_image_path = "\\Program Files\\QPST\\builds\\si_sample.hex";
        $nv_backup_path   = "\\Program Files\\QPST\\bin\\NV Backup\\test.qcn";
        $spc = "000000";
        $model_check_overide = 0;
        $clear_phone_error_log = 1;

        $nand_flash = $software_download->NANDFlash;
        print "Uses NAND flash: $nand_flash\n";

        $maximum_time = $software_download->ImageDownloadTimeout;
        print "Maximum time per operation: $maximum_time minutes\n";

        $maximum_time = 20;

        print "Download:\n image $phone_image_path,\n NV backup $nv_backup_path,\n SPC $spc,\n using $maximum_time minute timeout? (y/n) ";
        $reply = <STDIN>;
        chomp($reply);
        
        if ($reply =~ /^(y(|e(|s)))\b/i)    # y, ye, yes
        {
          $software_download->{ImageDownloadTimeout} = $maximum_time;

          # perform phone image download
          $software_download->DownloadPhoneImage($phone_image_path, $model_check_overide, $clear_phone_error_log, $nv_backup_path, $spc);

          $error = 0 + Win32::OLE->LastError();

          # get error message -- will be empty if op was successful
          $error_message = $software_download->GetErrorMessage();
          
          if ($error)
          {
            print "Encountered an error while calling the function\n";
            print "Final status <$error_message>\n";
          }
          else
          {
            if ($error_message eq "")
            {
              print "Operation completed successfully.\n";
            }
            else
            {
              print "Operation failed with message: $error_message.\n";
            }
          }
        }

        undef $software_download;
      }
      else
      {
        print "Unable to connect to Software Download component\n";
      }
    }
    else
    {
      print "Phone in bad state: $phone_status\n";
    }

    undef $port;
  }
  else
  {
    print "Port not available\n";
  }

  undef $qpst;
}
else
{
  print "QPST not available\n";
}

