use warnings;
use strict;
###############################################################################
# This script is written only for Windows. Tested on Windows 7. If error found on other OS and you need to do so, please contact with lingyunw 
# 
# AppId for the Automation server.
# When qpst config file is empty, all newly added port(auto or manual) will get QPST server global values for these 4 setting as initial values:
# 1.	Communication protocol( default to 1, "On initial connection switch to non-HDLC if device is compatible"). 
# 2.	AutoReset after dump( default to Enabled, Note in the task window show as “Desable”, so you will see the global value as “false” in your .config file) 
# 3.	Save memory dump uniquely by timestamp ( default to false )
# 4.	Sahara hello response( default to 0 )

# Change global settings won’t take any impact on existing ports( manually added ones,  list in Property_name='Ports', in QPSTServer.config files )
# Change global settings will apply to newly added ports afterwards.

# When QPST server is started, all settings in QPSTServer.config will be read into memory.
# When QPST server quit normally, all settings in memory will be saved to QPSTServer.config.
# When QPST server quit abnormally, all settings in memory will not be saved and all updates will be lost.


###############################################################################

use File::Copy qw(copy);

my $localConfPath = $ENV{localappdata};
my $myConfigFile = $localConfPath."\\QPST\\QPSTServer.config"; 



if(-f $myConfigFile){
    print("Plese confirm if the config path is correct:\n");
    print "$myConfigFile (y or n):";
    my $reply = <STDIN>;
    chomp($reply);

    while( $reply ne "y" )
    {
        print("Plese provide the correct path:\n");
        $myConfigFile = <STDIN>;
        chomp($myConfigFile);
        print "$myConfigFile (please confirm the path is correct: y or n):";
        $reply = <STDIN>;
        chomp($reply);
    }
    my $bakFile = $myConfigFile;
    $bakFile =~ s/QPSTServer\.config/QPSTServer_old\.config/;
    copy $myConfigFile, $bakFile;

    open my $in,  '<',  $bakFile      or die "Can't read old file: $!";
    open my $out, '>', $myConfigFile or die "Can't write new file: $!";
    while(<$in>){
        my $line = $_;
        if($line =~ m/DisableAutoResetAfterDump/){
            #print("$line \n");
            if($line =~ m/value='(true|false)'/ ){
                print("\n\tDisableAutoResetAfterDump = $1 (true means disable)\n");
            }
            
            print("Please input your value here(true or false):");
            my $myValue = <STDIN>;
            chomp($myValue);
            #input any white to skip
            if( $myValue eq ''){
                print $out $line;
                print("Skipped\n");
            }
            else{
                while($myValue !~ m/(true|false)/){
                    print("Your value is invalid.\n Please input your value here(true or false):");
                }
                $line =~ s/value='(true|false)'/value='$myValue'/;
                print $out $line;      
            }
        }
        elsif($line =~ m/DefaultSaharaHelloResponse/){
            #print("$line \n");
            if($line =~ m/value=\'([0-3])\'/ ){
                print("\n\tDefaultSaharaHelloResponse = $1 \n(0:Perform requeted action.\n1:If a download request, perform RAM dump instead.\n2:If a RAM dump request, perform a download instead.\n3:Do nothing until one of the other response modes is selected)\n");
            }
            
            print("Please input your value here([0-2]):");
            my $myValue = <STDIN>;
            chomp($myValue);
            #input any white to skip
            if( $myValue eq ''){
                print $out $line;
                print("Skipped\n");                
            }
            else{
                while($myValue !~ m/([0-3])/){
                    print("Your value is invalid.\n Please input your value here([0-3]):");
                }
                $line =~ s/value='([0-3])'/value='$myValue'/;
                print $out $line;            
            }
        }
        elsif($line =~ m/communication_protocol/){
            #print("$line \n");
            if($line =~ m/value=\'([0-2])\'/){
                print("\n\tcommunication_protocol = $1\n(0:Use the HDLC communication protocol only.\n1:On initial connection switch to non-HDLC if device is compatible.\n2:Support non-HDLC protocol but don't initiate the mode change)\n");
            }
            
            print("Please input your value here([0-2]):");
            my $myValue = <STDIN>;
            chomp($myValue);
            #input any white to skip
            if( $myValue eq ''){
                print $out $line;
                print("Skipped\n");
            }
            else{
                while($myValue !~ m/([0-2])/){
                    print("Your value is invalid.\n Please input your value here([0-2]):");
                }
                $line =~ s/value='([0-2])'/value='$myValue'/;
                print $out $line;            
            }
        }
        elsif($line =~ m/DefaultSaharaMemoryDumpUniqueTimestamp/){
            #print("$line \n");
            if($line =~ m/value='(true|false)'/){
                print("\n\tDefaultSaharaMemoryDumpUniqueTimestamp = $1\n");
            }
            
            print("Please input your value here(true or false):");
            my $myValue = <STDIN>;
            chomp($myValue);
            #input any white to skip
            if( $myValue eq ''){
                print $out $line;
                print("Skipped\n");                
            }
            else{
                while($myValue !~ m/(true|false)/){
                    print("Your value is invalid.\n Please input your value here(true or false):");
                }
                $line =~ s/value='(true|false)'/value='$myValue'/;
                print $out $line;            
            }
        }else{
            print $out $line;
        }
    }#while reading
    close($in) || die "Couldn't close file properly";
    close($out) || die "Couldn't close file properly";
    print("OK:\n")
}
else{
    die "Couldn't open file ".$myConfigFile;
}





      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      