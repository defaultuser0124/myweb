###############################################################################
# (c) Qualcomm, Inc. 2006
#
# Download a multi-image build to a phone. The MultiImageDownload function
# takes a directory as its first argument. The files in the build must have
# standard names and must all exist in the directory:
#
#  Required files:
#
#  partition.mbn    pbl.mbn (except in trusted mode)
#  qcsbl.mbn        qcsblhd_cfgdata.mbn
#  oemsbl.mbn       oemsblhd.mbn
#  amss.mbn         amsshd.mbn
#
#  Optional files:
#
#  apps.mbn         appshd.mbn
#  appsboot.mbn     appsboothd.mbn
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Cannot start $prod_id";
}

if (defined $qpst)
{
  $qpst_version = $qpst->AppVersion;
  print "Using QPST $qpst_version\n";

  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "Selected port $port_name\n";

    $port_status = $port->PhoneStatus;
    $phone_status = $phone_status_list{$port_status};

    if ($phone_status eq "phoneStatusReady")
    {
      # get softwaredownload object
      $software_download = $port->SoftwareDownload;
      
      if (defined $software_download)
      {
        # set up vars for various operations
        $phone_image_path = "\\Program Files\\QPST\\builds\\MultiImage\\Sample\\";
        $nv_backup_path   = "\\Program Files\\QPST\\bin\\NV Backup\\test.qcn";
        $spc = "000000";
        $overridePrtnTable = 0;
        $useTrustedMode = 0;        # If 0, send pbl.mbn to phone.
        $clear_phone_error_log = 1;
        $model_check_overide = 0;
        $nand_flash = $software_download->NANDFlash;
               
        # Reset maximum time per operation to 60 minutes.
        $software_download->{ImageDownloadTimeout} = 60;

        print "Uses NAND flash:          $nand_flash\n";
        print "Phone image path:         $phone_image_path\n";
        print "NV backup path:           $nv_backup_path\n";
        print "SPC:                      $spc\n";
        print "Override partition table: $overridePrtnTable\n";
        print "Use trusted mode:         $useTrustedMode\n";
        print "Clear phone error log:    $clear_phone_error_log\n";
        print "Override model check:     $model_check_overide\n";
        
        $maximum_time = $software_download->ImageDownloadTimeout;
        print "Operation timeout:        $maximum_time\n";
        
        print "\n";

        print "Download phone image to $port_name? (y/n) ";

        $reply = <STDIN>;
        chomp($reply);
        
        if ($reply =~ /^(y(|e(|s)))\b/i)    # y, ye, yes
        {
          $software_download->MultiImageDownload
          (
            $phone_image_path,        # directory containing files to download
            $nv_backup_path,          # nv backup file name
            $spc,                     # service provisioning code, default "000000"
            $overridePrtnTable,       # set to 1 to override partition table, else 0
            $useTrustedMode,          # set to 1 to use trusted mode, else 0
            $clear_phone_error_log,   # set to 1 to clear the phone error log
            $model_check_overide      # set to 1 to ignore model differences
          );

          $error = 0 + Win32::OLE->LastError();

          # get error message -- will be empty if op was successful
          $error_message = $software_download->GetErrorMessage();
        
          if ($error)
          {
            print "Encountered an error while calling the function\n";
            print "Final status <$error_message>\n";
          }
          else
          {
            if ($error_message eq "")
            {
              print "Operation completed successfully.\n";
            }
            else
            {
              print "Operation failed with message: $error_message.\n";
            }
          }
        }

        undef $software_download;
      }
      else
      {
        print "Unable to connect to Software Download component\n";
      }
    }
    else
    {
      print "Phone in bad state: $phone_status\n";
    }

    undef $port;
  }
  else
  {
    print "Port not available\n";
  }

  undef $qpst;
}
else
{
  print "QPST not available\n";
}

