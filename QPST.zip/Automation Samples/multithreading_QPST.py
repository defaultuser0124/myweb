#py testQPST_multithreading_usable.py


import sys
import os


#############
sys.coinit_flags = 0  #### THIS must be added before calling any com imports
#########################


import win32com.client
import pythoncom, threading, time


qpst = win32com.client.Dispatch("QPSTAtmnServer.Application")

if qpst:
    print("qpst created")
else:
    sys.exit()
 

def start_1(qpst):    
    
    if qpst:
        print("qpst got")
        pythoncom.CoInitializeEx(pythoncom.COINIT_MULTITHREADED)
        
        qpst._FlagAsMethod('GetCOMPortList')
        com_ports = qpst.GetCOMPortList()
        if com_ports:
            for ports in range(com_ports.PortCount):
                print('start_1: PortName: {}'.format(com_ports.PortName(ports)))
        else:
            print("com_ports null")

        pythoncom.CoUninitialize()    
        
    else:
        print("qpst null")

    
thread = threading.Thread(target=start_1,  kwargs={'qpst': qpst})    
thread2 = threading.Thread(target=start_1,  kwargs={'qpst': qpst})  
thread3 = threading.Thread(target=start_1,  kwargs={'qpst': qpst})  
thread4 = threading.Thread(target=start_1,  kwargs={'qpst': qpst})  
thread.start() 
thread2.start()
thread3.start()
thread4.start()
thread.join()
thread2.join()
thread3.join()
thread4.join()
qpst.Quit()
pythoncom.CoUninitialize()    

print("Done!")




