#example by lingyunw@qti.qualcomm.com
import win32com.client
from win32com.client import constants, DispatchBaseClass, CastTo, VARIANT
import sys

phone_status_list = {0:"phoneStatusNone", 5:"phoneStatusReady"}


qpst = win32com.client.Dispatch("QPSTAtmnServer.Application")
qpst._FlagAsMethod("GetSelectedPort")
qpst._FlagAsMethod("GetPort")
qpst._FlagAsMethod("ShowWindow")

#print("qpst:",qpst)
if qpst:
    print("Enter COM port name or press Enter to select from GUI: ")
    portname = sys.stdin.readline().strip()
    print("portname:", portname)
    port = qpst.GetPort(portname)
    
    if port:
        port_name = port.PortName;
        print("qport_name", port_name)
        port_status = port.PhoneStatus
        print("port_status", port_status, phone_status_list[port_status])
        if phone_status_list[port_status] == "phoneStatusReady":
            software_download = port.SoftwareDownload
            input()
            qcn = r"D:\qcns\00000000_1.xqcn"
            software_download.RestoreNV(qcn_path, '000000', 1)
            error = software_download.GetErrorMessage()
            if error:
                # Will return error string on failure case else empty
                raise Exception('Failed to restore qcn on the device: {}'.format(error))

print("End")        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
