' ---------------------------------------------------------------------------
'
' sendcommand.vbs
'
' QPSTAutomationServer example VBScript that demonstrates
' using the SendCommand method.
'
' ---------------------------------------------------------------------------

' tell script interpreter to keep going if errors occur
On Error Resume Next


' create qpst object
set QPST = CreateObject("QPSTAtmnServer.Application")

' tell user if we got an error accessing qpst
If Err.Number Then
   MsgBox("An error occurred accessing the QPST object: " & Err.Description & " (" & Err.Number & ")")
   Err.Clear
Else

   ' get portlist object
   set PortList = QPST.GetPortList

   ' get phone count
   Count = 0
   Count = PortList.PhoneCount
   
   ' tell user if we got an error accessing portlist
   If Err.Number Then
      MsgBox("An error occurred accessing the PortList object: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   End If

   if Count = 0 Then
      MsgBox("No phone found")
   Else

      ' get port id of first connected phone
      PortId = PortList.PortId(0)

      ' use port id to get port object
      set Port = QPST.GetPort(PortId)

      ' tell user if we got an error accessing port
      If Err.Number Then
         MsgBox("An error occurred accessing the Port object: " & Err.Description & " (" & Err.Number & ")")
         Err.Clear
      Else

         ' tell user we've found a phone
         MsgBox("Communication established with Port " & Port.PortName)

         ' build request packet
         NvCommandTemplate = "CSC128S"
         DiagNvReadF = Chr(38)
         NvMin1I = Chr(32)
         NvNull = Chr(0)
         Min1RequestString = NvCommandTemplate & DiagNvReadF & NvMin1I
         Min1Request = StringToBinary(Min1RequestString)
         
         ' send command (note that you have to parenthesize the request packet argument
         ' or else it goes through as a VT_BYREF|VT_VARIANT instead of a VT_ARRAY|VT_UI1)
         Min1Response = Port.SendCommand((Min1Request),2000)

         ' tell user if we got an error sending the command
         If Err.Number Then
            MsgBox("An error occurred sending the command: " & Err.Description & " (" & Err.Number & ")")
            Err.Clear
         Else

            ' tell user what the response was
            Min1ResponseString = BinaryToString(Min1Response)
            ResponseString = "Min1 Response length: " & Len(Min1ResponseString) & vbCr
            ResponseString = ResponseString & "value: "
            For i = 1 To Len(Min1ResponseString)
               ResponseString = ResponseString & "0x" & Hex(Asc(Mid(Min1ResponseString,i,1))) & " "
            Next
            MsgBox(ResponseString)

         End If

      End If

      ' clear port object ref
      set Port = Nothing

   End If


   ' clear object refs and tell server we're done
   set PortList = Nothing
   QPST.Quit()
   set QPST = Nothing

End If

' convert VT_ARRAY|VT_UI1 bytearray to string
Function BinaryToString(BinaryData)

   ' create stream object
   Set BinaryStream = CreateObject("ADODB.Stream")

   ' configure stream object for binary
   BinaryStream.Type = 1

   ' open stream and write text data to it
   BinaryStream.Open
   BinaryStream.Write BinaryData

   ' reset stream position to start
   BinaryStream.Position = 0

   ' change stream type to text
   BinaryStream.Type = 2
   BinaryStream.CharSet = "us-ascii"

   ' read binary data from stream
   BinaryToString = BinaryStream.ReadText

End Function

'convert string to VT_ARRAY|VT_UI1 bytearray
Function StringToBinary(Text)

   ' create stream object
   Set BinaryStream = CreateObject("ADODB.Stream")

   ' configure stream object for text
   BinaryStream.Type = 2
   BinaryStream.CharSet = "us-ascii"

   ' open stream and write text data to it
   BinaryStream.Open
   BinaryStream.WriteText Text

   ' reset stream position to start
   BinaryStream.Position = 0

   ' change stream type to binary
   BinaryStream.Type = 1

   ' read binary data from stream
   StringToBinary = BinaryStream.Read

End Function
