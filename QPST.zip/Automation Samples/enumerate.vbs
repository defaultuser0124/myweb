' ---------------------------------------------------------------------------
'
' getinfo.vbs
'
' QPSTAutomationServer example VBScript that enumerates active mobiles 
' and shows their state.
'
' ---------------------------------------------------------------------------

' tell script interpreter to keep going if errors occur
On Error Resume Next

' boolean string array for use below
Dim BoolStr(2)
BoolStr(0) = "No"
BoolStr(1) = "Yes"

' phone mode string array for use below
Dim ModeStr(7)
ModeStr(0) = "None"
ModeStr(1) = "Data Services"
ModeStr(2) = "Download"
ModeStr(3) = "Diagnostic"
ModeStr(4) = "Diagnostic Offline"
ModeStr(5) = "Reset"
ModeStr(6) = "Stream Download"
ModeStr(12) = "Sahara Download"

' phone status string array for use below
Dim StatusStr(6)
StatusStr(0) = "None"
StatusStr(1) = "Initialization In Progress"
StatusStr(2) = "Port Not Present"
StatusStr(3) = "Phone Not Present"
StatusStr(4) = "Phone Not Supported"
StatusStr(5) = "Ready"


' create qpst object
set QPST = CreateObject("QPSTAtmnServer.Application")

' tell user if we got an error accessing qpst
If Err.Number Then
   MsgBox("An error occurred accessing the QPST object: " & Err.Description & " (" & Err.Number & ")")
   Err.Clear
Else

   ' get portlist object
   set PortList = QPST.GetPortList

   ' collect info about portlist
   PLSummary = "Port List Information " & vbCr & vbCr
   PLSummary = PLSummary & "Phone Count: " & PortList.PhoneCount & " " & vbCr
   For i = 0 to PortList.PhoneCount - 1
      PLSummary = PLSummary & "Phone " & i & ": " & vbCr
      PLSummary = PLSummary & "   Port Name: " & PortList.PortName(i) & " " & vbCr
      PLSummary = PLSummary & "   Port Label: " & PortList.PortLabel(i) & " " & vbCr
      PLSummary = PLSummary & "   Port Id: " & PortList.PortId(i) & " " & vbCr
      PLSummary = PLSummary & "   Port is USB?: " & BoolStr(PortList.IsUSB(i)) & " " & vbCr
      PLSummary = PLSummary & "   Phone Model Number: " & PortList.ModelNumber(i) & " " & vbCr
      PLSummary = PLSummary & "   Phone Build Id: " & PortList.BuildId(i) & " " & vbCr
      PLSummary = PLSummary & "   Phone ESN: " & HEX(PortList.ESN(i)) & " " & vbCr
      PLSummary = PLSummary & "   Phone Mode: " & ModeStr(PortList.PhoneMode(i)) & " " & vbCr
      PLSummary = PLSummary & "   Phone Status: " & StatusStr(PortList.PhoneStatus(i)) & " " & vbCr
      PLSummary = PLSummary & "   Phone IMEI: " & PortList.IMEI(i) & " " & vbCr
   Next

   ' tell user if we got an error accessing portlist
   If Err.Number Then
      MsgBox("An error occurred accessing the PortList object: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else
      ' display portlist info summary
      MsgBox PLSummary
   End If


   ' show window so that there will be a selectedport
   QPST.ShowWindow

   ' get selectedport object
   set SelectedPort = QPST.GetSelectedPort

   ' collect info about selectedport
   SPSummary = "Selected Port Information " & vbCr & vbCr
   SPSummary = SPSummary & "Port Name: " & SelectedPort.PortName & " " & vbCr
   SPSummary = SPSummary & "Port Label: " & SelectedPort.PortLabel & " " & vbCr
   SPSummary = SPSummary & "Port Id: " & SelectedPort.PortId & " " & vbCr
   SPSummary = SPSummary & "Port is USB?: " & BoolStr(SelectedPort.IsUSB) & " " & vbCr
   SPSummary = SPSummary & "Model Number: " & SelectedPort.ModelNumber & " " & vbCr
   SPSummary = SPSummary & "Build Id: " & SelectedPort.BuildId & " " & vbCr
   SPSummary = SPSummary & "Phone ESN: " & HEX(SelectedPort.ESN) & " " & vbCr
   SPSummary = SPSummary & "Phone Mode: " & ModeStr(SelectedPort.PhoneMode) & " " & vbCr
   SPSummary = SPSummary & "Phone Status: " & StatusStr(SelectedPort.PhoneStatus) & " " & vbCr
   SPSummary = SPSummary & "IMEI: " & SelectedPort.IMEI & " " & vbCr

   ' tell user if we got an error accessing selectedport
   If Err.Number Then
      MsgBox("An error occurred accessing the SelectedPort object: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else
      ' display selectedport info summary
      MsgBox SPSummary
   End If

   ' hide window
   'QPST.HideWindow

   ' clear object refs and tell server we're done
   set SelectedPort = Nothing
   set PortList = Nothing
   QPST.Quit
   set QPST = Nothing

End If
