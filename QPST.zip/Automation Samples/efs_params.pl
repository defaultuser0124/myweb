###############################################################################
# (c) Qualcomm, Inc. 2006
#
# Demonstrate retrieving basic file system parameters.
#
###############################################################################

use Win32::OLE;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "port $port_name\n";

    $port_status = $port->PhoneStatus;

    if ($phone_status_list{$port_status} eq "phoneStatusReady")
    {
      $efs = $port->EFS;

      if (defined $efs)
      {
        $version = $efs->EFSVersion;
        print "EFS version $version\n";

        if ($version == 2)
        {
          $efs_max_name = $efs->EFSMaxName;
          print "max name $efs_max_name\n";

          $efs_max_path = $efs->EFSMaxPath;
          print "max path $efs_max_path\n";

          $efs_max_link_depth = $efs->EFSMaxLinkDepth;
          print "max link depth $efs_max_link_depth\n";

          $efs_max_file_size = $efs->EFSMaxFileSize;
          print "max file size $efs_max_file_size\n";

          $efs_max_dirs = $efs->EFSMaxDirEntries;
          print "max dirs $efs_max_dirs\n";

          $efs_max_mnts = $efs->EFSMaxMounts;
          print "max mounts $efs_max_mnts\n";
        }
        else
        {
          print "Incompatible EFS version\n";
        }
      }
      else
      {
        print "No EFS interface for this port\n";
      }

      undef $efs;
    }
    else
    {
      print "Phone not ready\n";
    }
  }
  else
  {
    print "Port not available\n";
  }

  undef $port;
}
else
{
  print "QPST not available\n";
}

undef $qpst;

