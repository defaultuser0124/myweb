###############################################################################
# (c) Qualcomm, Inc. 2010
#
# This script demonstrates the new DownloadBySettings() interface for Software
# Download.
# 
# It's advantage is that you can retrieve a DownloadSettings object that is
# initialized for a specific device, and then change some of its settings.
# If the phone changes COM ports when it changes to download mode, you can
# also continue the download on the new COM port (you will have to provide
# the logic to locate the new COM port and add it to the QPST server).
# 
# You can also download to a phone that is already in download mode (for
# example a phone with blank flash in emergency download mode), by
# configuring the DownloadSettings object. This process is not possible with
# the other software download automation APIs.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

my $prod_id = "QPSTAtmnServer.Application";
my $qpst = undef;

# Get a handle to the QPST Automation server.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Cannot start $prod_id";
}

if (defined $qpst)
{
  my $qpst_version = $qpst->AppVersion;
  print "Using QPST $qpst_version\n";

  print "Enter COM port name or press Enter to select from GUI: ";
  chomp(my $port_name = <STDIN>);

  my $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  print "Enter search path for files (path1;path2 ...): ";
  chomp(my $phoneImageSearch = <STDIN>);

  if (defined $port)
  {
    $software_download = $port->SoftwareDownload;

    if (defined $software_download)
    {
       # Get the DownloadSettings object for this port.
       $swdl_settings = $software_download->DownloadSettings;

       if (defined $swdl_settings)
       {
          my $last_error = 0;

          if ($swdl_settings->IsKnownConfiguration)
          {
             # If we get here the phone already has AMSS running and QPST recognizes the device.
             print "IsKnownConfiguration = true\n";

             # $qpstDir must end with \ so we can concatenate the file name.
             # Remember if you use "\" in a file path you must precede it with an escape: "\\"
             #my $qpstDir = "C:\\Program Files\\Qualcomm\\QPST\\";
             my $qpstDir = "C:\\Documents and Settings\\All Users\\Application Data\\Qualcomm\\QPST\\NV Backup\\";

             my $nvBackupFile = "";

             if (-d $qpstDir) {
                $nvBackupFile = $qpstDir . "test.qcn";

                print "Backup NV items to $nvBackupFile? (y/n) ";
                chomp (my $doQcn = <STDIN>);

                if ($doQcn =~ /^(y(|e(|s)))\b/i) {
                   print "Will perform NV backup...\n";
                }
                else {
                   $nvBackupFile = "";
                }
             }
             else {
                print "Backup dirctory $qpstDir does not exist, NV backup/restore disabled.\n";
             }

             # Note- after every SetParam you should use:
             # $error = 0 + Win32::OLE->LastError();
             # to test for an error. $error != 0 indicates the SetParam returned an error code.

             # prlrestoremode:
             # "always" - always try to restore the PRL. Will fail if the PRL writes to a SIM/UIM card.
             # "rtre_config nv_only" - restore only if PRL writes to NV (actually a EFS file).
             $swdl_settings->SetParam("prlrestoremode", "rtre_config nv_only");
             $last_error = 0 + Win32::OLE->LastError();
             if ($last_error) {
                print "SetParam downloadTarget\n";
                print_error($last_error, $swdl_settings);
             }

             # Set a path for NV backup/restore. To skip the backup don't set this parameter.
             if ($nvBackupFile ne "") {
                $swdl_settings->SetParam("filepathqcn", $nvBackupFile);

                $last_error = 0 + Win32::OLE->LastError();
                if ($last_error) {
                   print "SetParam filepathqcn\n";
                   print_error($last_error, $swdl_settings);
                }
             }

             # Default SPC is "000000".
             #$swdl_settings->SetParam("SPC", "000001");
          }
          else
          {
             # If we get here the phone is stuck in download mode or QPST doesn't recognize
             # the device.
             print "IsKnownConfiguration = false\n";
          }

          # downloadTarget:
          # "nand sb 2.0" - NAND flash, Secure Boot 2.0
          # "nand sb 2.0 boot only" - NAND flash, Secure Boot 2.0, only dbl, fsbl, osbl.
          # "eMMC" - eMMC device with files specified by XML document.
          $swdl_settings->SetParam("downloadTarget", "eMMC");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam downloadTarget\n";
             print_error($last_error, $swdl_settings);
          }

          # searchPaths - must set this BEFORE filePathXML, mmcFilePathBoot, or flashProgrammer.
          $swdl_settings->SetParam("searchPaths", $phoneImageSearch);
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam searchPaths\n";
             print_error($last_error, $swdl_settings);
          }

          # filePathXML
          $swdl_settings->SetParam("filePathXML", "rawprogram0.xml");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam filePathXML\n";
             print_error($last_error, $swdl_settings);
          }

          # filePathPatch
          $swdl_settings->SetParam("filePathPatch", "patch0.xml");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam filePathPatch\n";
             print_error($last_error, $swdl_settings);
          }

          # emmcFilePathBoot
          $swdl_settings->SetParam("emmcFilePathBoot", "msimage.mbn");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam emmcFilePathBoot\n";
             print_error($last_error, $swdl_settings);
          }

          # flashprogrammer
          $swdl_settings->SetParam("flashprogrammer", "emmcbld.hex");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam flashprogrammer\n";
             print_error($last_error, $swdl_settings);
          }

          # Skip reset of phone at end of download. Default is false ("0").
          #$swdl_settings->SetParam("skipreset", "0");

          # Wait time for phone to restart (seconds).
          $swdl_settings->SetParam("restart timeout", "10");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam restart timeout\n";
             print_error($last_error, $swdl_settings);
          }

          #####################################################################
          # Display current download configuration settings.

          # Can only use GetParam with "devicename".
          my $dev_name = $swdl_settings->GetParam("devicename");
          print "devicename = \"$dev_name\"\n";

          my $spc = $swdl_settings->GetParam("SPC");
          print "SPC = \"$spc\"\n";

          my $clrErrLog = $swdl_settings->GetParam("clearPhoneErrorLog");
          print "clearPhoneErrorLog = $clrErrLog\n";

          my $prlRest = $swdl_settings->GetParam("prlrestoremode");
          print "prlrestoremode = $prlRest\n";

          my $dlTarget = $swdl_settings->GetParam("downloadTarget");
          print "downloadTarget = \"$dlTarget\"\n";

          my $qcnPath = $swdl_settings->GetParam("filepathqcn");
          print "filepathqcn = $qcnPath\n";

          my $fp_name = $swdl_settings->GetParam("flashprogrammer");
          print "flashprogrammer = $fp_name\n";

          my $restartTimeout = $swdl_settings->GetParam("restart timeout");
          print "restart timeout = $restartTimeout\n";

          my $searchPaths = $swdl_settings->GetParam("searchPaths");
          print "searchPaths = $searchPaths\n";

          my $filePathXML = $swdl_settings->GetParam("filePathXML");
          print "filePathXML = $filePathXML\n";

          my $emmcFilePathBoot = $swdl_settings->GetParam("emmcFilePathBoot");
          print "emmcFilePathBoot = $emmcFilePathBoot\n";

          #####################################################################
          # Start the download. Will wait here until it completes or fails.

          if ($last_error) {
             print "Download skipped because of errors\n";
          }
          else {
             print "Begin DownloadBySettings()\n";

             $software_download->DownloadBySettings($swdl_settings);

             #print "Press Enter to continue...";
             #chomp(my $return = <STDIN>);

             # Error returned by call to DownloadBySettings?
             $last_error = 0 + Win32::OLE->LastError();

             # Error during download?
             my $error_message = $software_download->GetErrorMessage();

             if ($last_error)
             {
                print "Error returned by DownloadBySettings:\n";
                print "Final status <$error_message>\n";
             }
             else
             {
                if ($error_message eq "")
                {
                   print "Download completed successfully\n";
                }
                else
                {
                   print "Download completed with error:\n";
                   print "Final status <$error_message>\n";
                }
             }
          }

          undef $swdl_settings;
       }
       else
       {
          print "Failed to access DownloadSettings component\n";
       }

       undef $software_download;
    }
    else
    {
       print "Failed to access SoftwareDownload component\n";
    }

    undef $port;
  }
  else
  {
    print "Port not available\n";
  }

  undef $qpst;
}
else
{
  print "QPST not available\n";
}

sub print_error
{
  my ($error, $error_obj) = @_;

  print "OLE error:\n";

  my ($error_hex) = sprintf "%08lx", $error + 0;

  my ($description) = Variant(VT_BSTR | VT_BYREF, "");
  my ($guid)        = Variant(VT_BSTR | VT_BYREF, "");
  my ($help_ctx)    = Variant(VT_I4   | VT_BYREF, -1);
  my ($help_file)   = Variant(VT_BSTR | VT_BYREF, "");
  my ($prog_src)    = Variant(VT_BSTR | VT_BYREF, "");

  # Calling GetLastError resets the saved error information.
  $error_obj->GetLastError($description, $guid, $help_ctx, $help_file, $prog_src);

# For more information on IErrorInfo, look up this topic on msdn.microsoft.com, or
# try the following URL:
# http://msdn.microsoft.com/library/default.asp?url=/library/en-us/automat/html/4dda6909-2d9a-4727-ae0c-b5f90dcfa447.asp

  print "HRESULT:                 <$error_hex>\n";
  print "IErrorInfo description:  <$description>\n";
  print "IErrorInfo help file:    <$help_file>\n";
  print "IErrorInfo help context: <$help_ctx>\n";
  print "IErrorInfo error source: <$prog_src>\n";
  print "IErrorInfo error intf:   <$guid>\n";
}

