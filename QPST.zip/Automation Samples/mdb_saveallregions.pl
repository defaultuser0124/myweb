###############################################################################
# (c) Qualcomm, Inc. 2006
#
# This script will check if an EFS directory is empty.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;


###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
   $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
   $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
      $qpst->ShowWindow();

      print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
      <STDIN>;

      $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady) ;

   if (defined $port)
   {
      $port_name = $port->PortName;
      print "port $port_name\n";

      $port_status = $port->PhoneStatus;

      if ($phone_status_list{$port_status} eq "phoneStatusReady")
      {
         $memory_debug = $port->MemoryDebug;

         if (defined $memory_debug)
         {
            $saveLocation = "C:\\Documents and Settings\\All Users\\Desktop\\mdb_auto";
            if (!-e $saveLocation)
            {
               mkdir $saveLocation;
            }

            print "Entering SaveAllRegions.\n";

            $memory_debug->{UseUnframedMemoryRead} = 0;  # boolean to tell QPST to use higher speed unframed memory reads

            $memory_debug->SaveAllRegions($saveLocation);
            print "Exiting SaveAllRegions.\n";

            if (Win32::OLE->LastError == 0) 
            {
               print "SaveAllRegions succeeded.\n";
            }
            else
            {
                $error = Win32::OLE->LastError();
                print "SaveAllRegions failed:\n$error\n";
            }
         }
         else
         {
            print "No MemoryDebug interface for this port\n";
         }

         undef $memory_debug;
     }
     else
     {
        print "Phone not ready\n";
     }
  }
  else
  {
     print "Port not available\n";
  }

  undef $port;
}
else
{
  print "QPST not available\n";
}

#print "Press enter to exit";
#<STDIN>;

undef $qpst;

