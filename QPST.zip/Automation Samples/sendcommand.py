import win32com.client
from win32com.client import constants, DispatchBaseClass, CastTo, VARIANT
import sys
import pythoncom

qpst = win32com.client.Dispatch("QPSTAtmnServer.Application")
qpst._FlagAsMethod("GetPort")


if qpst:
    print("Enter COM port name or press Enter to select from GUI: ")
    portname = sys.stdin.readline().strip()
    port = qpst.GetPort(portname)
    if port:
        port_name = port.PortName;
        print("qport_name", port_name)
        port_status = port.PhoneStatus
        if port_status == 5:
            request_data = bytes([0xc])
            v=win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_UI1, bytearray(request_data))
            response_data = port.SendCommand(v, 3000)

qpst.Quit()
qpst = None



 

