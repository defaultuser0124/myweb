#py testQPST_multithreading_usable.py

import win32com.client
import sys
import os
import pythoncom, threading, time
sem = threading.Semaphore()

pythoncom.CoInitialize()
qpst = win32com.client.Dispatch("QPSTAtmnServer.Application")

if qpst:
    print("qpst created")
else:
    sys.exit()
 
qpst_marshaled = pythoncom.CreateStreamOnHGlobal()    
#qpst_marshaled = pythoncom.CoMarshalInterThreadInterfaceInStream(pythoncom.IID_IDispatch, qpst)   
pythoncom.CoMarshalInterface(qpst_marshaled, 
                             pythoncom.IID_IDispatch, 
                             qpst._oleobj_, 
                             pythoncom.MSHCTX_LOCAL, 
                             pythoncom.MSHLFLAGS_TABLESTRONG)

def start_1(qpst_id):  
    
    if qpst_id:
        sem.acquire()
        print("qpst got") 
        try:
            pythoncom.CoInitialize()     
            
            print("entering...")        
            qpst_id.Seek(0,0)
            qps_class_id = pythoncom.CoUnmarshalInterface(qpst_id, pythoncom.IID_IDispatch)        
            print("leaving...")
        except:
            pass
        finally:
            sem.release()
        
        qpst = None
        try:
            qpst = win32com.client.GetActiveObject(Class=qps_class_id)  
            if qpst:
                print("QPSTAtmnServer.Application get ready")
        except:
            qpst = win32com.client.Dispatch(qps_class_id)            
        if qpst:    
            qpst._FlagAsMethod('GetCOMPortList')
            com_ports = qpst.GetCOMPortList()
            if com_ports:
                for ports in range(com_ports.PortCount):
                    print('start_1: PortName: {}'.format(com_ports.PortName(ports)))
            else:
                print("com_ports null")            
    else:
        print("qpst null")
    input("Waiting start...") 
    
    
thread = threading.Thread(target=start_1,  kwargs={'qpst_id': qpst_marshaled})    
thread2 = threading.Thread(target=start_1,  kwargs={'qpst_id': qpst_marshaled})  
thread.start() 
thread2.start()
thread.join()
thread2.join()

print("Done!")
qpst.Quit()



