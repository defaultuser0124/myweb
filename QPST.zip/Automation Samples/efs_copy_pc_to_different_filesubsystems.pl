###############################################################################
# (c) Qualcomm, Inc. 2006-2009
#
# This script will copy a file from the PC to the phone.
#
# Demonstrate use of CreateDirectoryAndWriteFile.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;
use efs_error;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady) ;

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "port $port_name\n";

    $port_status = $port->PhoneStatus;

    if ($phone_status_list{$port_status} eq "phoneStatusReady")
    {
      # get the current file subsystem id (19 is 'primary' or default, 62 is 'alternate')         
      $efsPrimary = $port->EFS;			# the same as $port->GetEFSSubsystem( 19 );	
      $efsAlternate = $port->GetEFSSubsystem( 62 );

      
      if (defined $efsPrimary and defined $efsAlternate)
      {
        $subsys = $efsPrimary->FileSubsystemId;
        print "FileSubsystem = $subsys\n";
                
        $version = $efsPrimary->EFSVersion;
        print "EFS version $version\n";
        
        if ($version == 2)
        {
          print "PC path ? ";
          $reply = <STDIN>;
          chomp($reply);

          $pc_path = $reply;
          $efs_path = "";

          if ($pc_path ne "")
          {
            print "EFS path ? ";
            $efs_path = <STDIN>;
            chomp($efs_path);
          }

          if ($efs_path ne "")
          {
             $efsPrimary->CreateDirectoryAndWriteFile($efs_path, $pc_path); # copy a file to �primary� file system

             $error = Win32::OLE->LastError();

             if (($error + 0) != 0)
             {
                print_error($error, $efs);
             }
                 
             $efsAlternate->CreateDirectoryAndWriteFile($efs_path, $pc_path); # copy a file to �alternate� file system

             $error = Win32::OLE->LastError();

             if (($error + 0) != 0)
             {
                print_error($error, $efs);
             }
          }
        }
        else
        {
          print "Incompatible EFS version\n";
        }
      }
      else
      {
        print "No EFS interface for this port\n";
      }

      undef $efsPrimary;
      undef $efsAlternate;
    }
    else
    {
      print "Phone not ready\n";
    }
  }
  else
  {
    print "Port not available\n";
  }

  undef $port;
}
else
{
  print "QPST not available\n";
}

undef $qpst;

