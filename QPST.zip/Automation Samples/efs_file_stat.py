﻿#example by QPST
import win32com.client
from win32com.client import constants, DispatchBaseClass, CastTo, VARIANT
import sys

phone_status_list = {0:"phoneStatusNone", 5:"phoneStatusReady"}


qpst = win32com.client.Dispatch("QPSTAtmnServer.Application")
qpst._FlagAsMethod("GetSelectedPort")
qpst._FlagAsMethod("GetPort")
qpst._FlagAsMethod("ShowWindow")

#print("qpst:",qpst)
if qpst:
    print("Enter COM port name or press Enter to select from GUI: ")
    portname = sys.stdin.readline().strip()
    print("portname:", portname)
    if not portname:
        qpst.ShowWindow()
        print("Select a phone on the GUI,\nthen return to this window and press enter to continue")       
        port = qpst.GetSelectedPort()
        print("press enter again to continue")
        input()
        #print("port :", port)
    else:
        #print("qpst :", qpst, "portname :", portname)
        port = qpst.GetPort(portname)
        #print("port :", port)
    
    if port:
        port_name = port.PortName;
        print("qport_name", port_name)
        port_status = port.PhoneStatus
        print("port_status", port_status, phone_status_list[port_status])
        if phone_status_list[port_status] == "phoneStatusReady":
            efs = port.EFS
            if efs:
                version = efs.EFSVersion
                print("EFS version:", version)
                if version == 2:
                    print("EFS path ? ")
                    efs_path = sys.stdin.readline().strip()
                    if efs_path:
                        efs._FlagAsMethod("StatFile")
                        mode = win32com.client.VARIANT(pythoncom.VT_BSTR | pythoncom.VT_BYREF, "")
                        size = win32com.client.VARIANT(pythoncom.VT_I4   | pythoncom.VT_BYREF, 0)
                        nlink = win32com.client.VARIANT(pythoncom.VT_I4   | pythoncom.VT_BYREF, 0)
                        atime = win32com.client.VARIANT(pythoncom.VT_BSTR | pythoncom.VT_BYREF, "")
                        mtime = win32com.client.VARIANT(pythoncom.VT_BSTR | pythoncom.VT_BYREF, "")
                        ctime = win32com.client.VARIANT(pythoncom.VT_BSTR | pythoncom.VT_BYREF, "")
                        error = 0
                        try:
                            print("try StatFile")
                            efs.StatFile(efs_path, mode, size, nlink, atime, mtime, ctime);                            
                        except Exception as ex:
                            print("except")
                            print(ex)
                            error = 1
                        
                        if error == 0:
                            print("mode:", mode)
                            print("size:", size)
                            print("n link:", nlink)
                            print("a-time:", atime)
                            print("m-time:", mtime)
                            print("c-time:", ctime)

          

else:
    print("qpst created fail.")

print("end")





