' ---------------------------------------------------------------------------
'
' provisioning.vbs
'
' QPSTAutomationServer example VBScript that gets and sets nv items
' and roaming list.
'
' ---------------------------------------------------------------------------

' tell script interpreter to keep going if errors occur
On Error Resume Next

' create qpst object
set QPST = CreateObject("QPSTAtmnServer.Application")

' tell user if we got an error accessing qpst
If Err.Number Then
   MsgBox("An error occurred accessing the QPST object: " & Err.Description & " (" & Err.Number & ")")
   Err.Clear
Else

   ' get selectedport object
   set SelectedPort = QPST.GetSelectedPort

   ' tell user if we got an error accessing selectedport
   If Err.Number Then
      MsgBox("An error occurred accessing the SelectedPort object: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else

      ' get provisioning object
      set Provisioning = SelectedPort.Provisioning

      ' set phone offline
      SelectedPort.Offline

      ' send SPC
      SelectedPort.SendSPC "000000"

      ' test each call in a separate subroutine
      TestGetNVItem
      TestSendNVItem
      TestGetPRL
      TestSendPRL

      ' reset phone
      SelectedPort.Reset

   End If

   ' hide window
   'QPST.HideWindow

   ' clear object refs and tell server we're done
   set Provisioning = Nothing
   set SelectedPort = Nothing
   QPST.Quit
   set QPST = Nothing

End If

Sub TestGetNVItem

   ' clear error if any
   If Err.Number Then
      Err.Clear
   End If

   ' set up vars for get nv item
   Item = 71
   Title = "Banner"
   ' (other fun ones: 0 "ESN", 2 "Major Version", 3 "Minor Version", 8 "Mobile Model")

   ' tell user what we're about to do and give them a chance to opt out
   UserChoice = MsgBox("Click OK to Get NV Item " & Item & " (" & Title & ") from " & SelectedPort.PortName, vbOKCancel)
   If UserChoice <> vbOK Then Return

   ' get nv item
   Data = Provisioning.GetNVItem(Item)

   ' tell user if we got an error
   If Err.Number Then
      MsgBox("An error occurred getting the NV Item: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else

      ' display result
      DataBinaryString = BinaryToString(Data)
      DataLength = Len(DataBinaryString)
      DataHexString = ""
      DataCharString = ""
      For i = 1 to DataLength
         iChar = Asc(Mid(DataBinaryString,i,1))
         DataHexString = DataHexString & "0x" & Hex(iChar) & " "
         If iChar = 0 Then
            iChar = 32
         End If
         DataCharString = DataCharString & Chr(iChar)
      Next
      MsgBox("NV Item " & Item & vbCr & "Ascii: " & DataCharString & vbCr & "Hex: " & DataHexString & vbCr & "Length: " & DataLength)

   End If

End Sub

Sub TestSendNVItem

   ' clear error if any
   If Err.Number Then
      Err.Clear
   End If

   ' set up vars for send nv item
   Item = 71
   Title = "Banner"
   DataString = "Provisioned"
   ' (to compose a DataString containing non-ascii values:
   '  DataString = Chr(0) & Chr(12) & Chr(3) & ...)
   Data = StringToBinary(DataString)

   ' tell user what we're about to do and give them a chance to opt out
   UserChoice = MsgBox("Click OK to Send NV Item " & Item & " (" & Title & ") data <" & DataString & "> length " & Len(DataString) & " to " & SelectedPort.PortName, vbOKCancel)
   If UserChoice <> vbOK Then Return

   ' send nv item
   ' (note that you have to parenthesize the data argument or else it 
   ' goes through as a VT_BYREF|VT_VARIANT instead of a VT_ARRAY|VT_UI1)
   Provisioning.SendNVItem Item, (Data)

   ' tell user if we got an error
   If Err.Number Then
      MsgBox("An error occurred sending the NV Item: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else

      ' display result
      MsgBox("Send NV Item " & Item & " was successful.")

   End If

End Sub

Sub TestGetPRL

   ' clear error if any
   If Err.Number Then
      Err.Clear
   End If

   ' set up vars for get prl
   Index = 0
   rlFilePath = "C:\temp\test.prl"

   ' tell user what we're about to do and give them a chance to opt out
   UserChoice = MsgBox("Click OK to Get PRL with index " & Index & " to file " & rlFilePath, vbOKCancel)
   If UserChoice <> vbOK Then Return

   ' get prl
   Provisioning.GetPRL Index, rlFilePath

   ' tell user if we got an error
   If Err.Number Then
      MsgBox("An error occurred getting the PRL: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else

      ' display result
      MsgBox("Get PRL " & Index & " to file " & rlFilePath & " was successful.")

   End If

End Sub

Sub TestSendPRL

   ' clear error if any
   If Err.Number Then
      Err.Clear
   End If

   ' set up vars for send prl
   Index = 0
   rlFilePath = "C:\temp\test.prl"

   ' tell user what we're about to do and give them a chance to opt out
   UserChoice = MsgBox("Click OK to Send PRL file " & rlFilePath & " with index " & Index, vbOKCancel)
   If UserChoice <> vbOK Then Return

   ' send prl
   Provisioning.SendPRL Index, rlFilePath

   ' tell user if we got an error
   If Err.Number Then
      MsgBox("An error occurred sending the PRL: " & Err.Description & " (" & Err.Number & ")")
      Err.Clear
   Else

      ' display result
      MsgBox("Send PRL " & Index & " from file " & rlFilePath & " was successful.")

   End If

End Sub

' convert VT_ARRAY|VT_UI1 bytearray to string
Function BinaryToString(BinaryData)

   ' create stream object
   Set BinaryStream = CreateObject("ADODB.Stream")

   ' configure stream object for binary
   BinaryStream.Type = 1

   ' open stream and write text data to it
   BinaryStream.Open
   BinaryStream.Write BinaryData

   ' reset stream position to start
   BinaryStream.Position = 0

   ' change stream type to text
   BinaryStream.Type = 2
   BinaryStream.CharSet = "us-ascii"

   ' read binary data from stream
   BinaryToString = BinaryStream.ReadText

End Function

'convert string to VT_ARRAY|VT_UI1 bytearray
Function StringToBinary(Text)

   ' create stream object
   Set BinaryStream = CreateObject("ADODB.Stream")

   ' configure stream object for text
   BinaryStream.Type = 2
   BinaryStream.CharSet = "us-ascii"

   ' open stream and write text data to it
   BinaryStream.Open
   BinaryStream.WriteText Text

   ' reset stream position to start
   BinaryStream.Position = 0

   ' change stream type to binary
   BinaryStream.Type = 1

   ' read binary data from stream
   StringToBinary = BinaryStream.Read

End Function
