###############################################################################
# (c) Qualcomm Technologies Inc. 2013
#
# Demonstrates new Automation methods that support the Sahara data transfer
# protocol (crash dump and software download).
#
# New APIs for Sahara mode:
#  SaharaHelloRsp()
#  EnableSaharaSupport()
#  EnableDumpTimeStamp()
#  EnableSaharaAutoReset()
#  LastSaharaEvent()
#  SaharaConfigXML()
#  XmlPath()
#  PathOneTimeUse()
#  MemoryDumpFolder()
#  SendSaharaResetCmd()
#  SaharaAbortDumpAndReset()
#  EnableSaharaBootMode()
#  LastMemoryDumpPath()
#  SaharaContinue();
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
my $prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
   print "Enter COM port name: ";
   my $port_name = <STDIN>;
   chomp($port_name);

   my $port = undef;

   if ($port_name ne "")
   {
      $port = $qpst->GetPort($port_name);
   }

   if (defined $port)
   {
      # Display initial QPST configuration state.
	   while(true)
	   {
			my $MSMSerialNumber = $port->QCSerialNumber;
			if ($MSMSerialNumber eq "")
			{
				print "Finding MSM serial number...\n";
				sleep(1);
			}
			else
			{
				print "MSM serial number is $MSMSerialNumber\n";
				print "Exiting the loop\n";
				last;
			}
	   }

      undef $port;
   }

   undef $qpst;
}

print "Done!\n";