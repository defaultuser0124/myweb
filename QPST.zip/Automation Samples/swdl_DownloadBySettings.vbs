' VB Script for downloading files to a device
Option Explicit
Dim objAtmnServer, tmpIn, eFlashPrg, srvVersion, imageDir, objFSO, port, swDownload
Dim swdlSet, errMsg, memoryDebug

eFlashPrg = "\eNPRG7x30.hex"

Wscript.StdOut.Write "Getting handle to automation server" & vbCrLf

Set objAtmnServer = CreateObject("QPSTAtmnServer.Application")
Wscript.StdOut.Write "Got handle to automation server" & vbCrLf
srvVersion = objAtmnServer.AppVersion
WScript.StdOut.Write "QPST Version: " & srvVersion & vbCrLf

' Now that we have the image dir look for the port name
Set port = GetPort(objAtmnServer)
If port is Nothing Then
  WScript.StdOut.Write "Failed to get valid port exiting..." & vbCrLf
  TerminateScript(-2)
End If

' Get the Image Dir and make sure it is valid
imageDir = GetImageDir()
If imageDir = "" Then
  WScript.StdOut.Write "Folder does not exist exiting..." & vbCrLf
  TerminateScript(-1)
End If


' We have a port with active phone on it now
Set swDownload = port.SoftwareDownload
If swDownload is Nothing Then
  WScript.StdOut.Write "Failed to handle to software download interface exiting..." & vbCrLf
  TerminateStript(-3)
End If

' Get handle to software download settings
Set swdlSet = SetupDownload(swDownload, imageDir,eFlashPrg)
If swdlSet is Nothing Then
  WScript.StdOut.Write "Failed to set up software download settings exiting..." & vbCrLf
  TerminateStript(-4)
End If
  
' Now go ahead and do the actual download
swDownload.DownloadBySettings(swdlSet)

' Get and print any errors returned
errMsg = swDownload.GetErrorMessage()

WScript.StdOut.Write errMsg & vbCrLf

TerminateScript(0)


' -------------------------------------------------------------------------------------------
' -------------------------------------------------------------------------------------------
' ------------------------------     SUBS and FUNCTIONS    ----------------------------------
' -------------------------------------------------------------------------------------------
' -------------------------------------------------------------------------------------------

Sub TerminateScript(e)
  objAtmnServer.quit
  Wscript.StdOut.Write "Terminating program error " & e & vbCrLf
  WScript.Quit(e)
End Sub

Sub DumpMemory(port)
  ' Get a pointed to memory dump
  Set memoryDebug = port.MemoryDebug
  
  If Not memoryDebug Is Nothing Then
    WScript.StdOut.Write "Failed to get handle to memory debug interface..." & vbCrLf
    TerminateScript(-5)
  End If

  memoryDebug.SaveAllRegions("C:\temp\dump.bin")
  WScript.StdOut.Write "Finished dumping memory from phone!" & vbCrLf
  memoryDebug = Nothing
End Sub

Function SetupDownload(swdl, imageDir,eFlashPrg)
  Dim tmpIn, swdlSettings, nvBackup
  
  Set swdlSettings = swdl.DownloadSettings
  If swdlSettings is Nothing Then
    WScript.StdOut.Write "Failed to handle to software download interface exiting..." & vbCrLf
    TerminateStript(-3)
  End If
  
  ' If it is known configuration then we are in AMSS mode so try to back up NV
  nvBackup = ""
  If swdlSettings.IsKnownConfiguration Then
    WScript.StdOut.Write "Phone is in AMSS mode do you want to backup NV? (y/n) " & vbCrLf
    tmpIn = WScript.StdIn.ReadLine
    If tmpIn = "y" Then
       nvBackup = "C:\Program Files\Qualcomm\QPST\test.qcn"
       swdlSettings.SetParam "filepathqcn", nvBackup
    End If

    swdlSettings.SetParam "phoneimagepath", imageDir
    swdlSettings.SetParam "prlrestoremode", "rtre_config nv_only"
  Else
    WScript.StdOut.Write "Phone is in download mode" & vbCrLf
    swdlSettings.SetParam "useTrustedMode", "1"
    swdlSettings.SetParam "downloadTarget", "nand sb 2.0"
    swdlSettings.SetParam "phoneimagepath", imageDir
    swdlSettings.SetParam "flashprogrammer", imageDir & eFlashPrg
    swdlSettings.SetParam "restart timeout", "5"
  End If

  ' Print out device information for download
  WScript.StdOut.Write "devicename: " & swdlSettings.GetParam("devicename") & vbCrLf
  WScript.StdOut.Write "SPC: " & swdlSettings.GetParam("SPC") & vbCrLf
  WScript.StdOut.Write "overridePrtnTable: " & swdlSettings.GetParam("overridePrtnTable") & vbCrLf
  WScript.StdOut.Write "useTrustedMode: " & swdlSettings.GetParam("useTrustedMode") & vbCrLf
  WScript.StdOut.Write "clearPhoneErrorLog: " & swdlSettings.GetParam("clearPhoneErrorLog") & vbCrLf
  WScript.StdOut.Write "prlrestoremode: " & swdlSettings.GetParam("prlrestoremode") & vbCrLf
  WScript.StdOut.Write "downloadTarget: " & swdlSettings.GetParam("downloadTarget") & vbCrLf
  WScript.StdOut.Write "filepathqcn: " & swdlSettings.GetParam("filepathqcn") & vbCrLf
  WScript.StdOut.Write "filepathpartition: " & swdlSettings.GetParam("filepathpartition") & vbCrLf
  WScript.StdOut.Write "flashprogrammer: " & swdlSettings.GetParam("flashprogrammer") & vbCrLf
  WScript.StdOut.Write "restart timeout: " & swdlSettings.GetParam("restart timeout") & vbCrLf
  Set SetupDownload = swdlSettings
End Function

Function GetPort(atmn)
  Dim pName 
  WScript.StdOut.Write "Enter COM port name or press Enter to select from GUI: "
  pName = WScript.StdIn.ReadLine  
  If pName = "" Then
    atmn.ShowWindow()
    WScript.StdOut.Write "Select a phone in GUI then press enter in this in window" & vbCrLf
    WScript.StdIn.ReadLine   
    Set GetPort = atmn.GetSelectedPort()
  Else
    Set GetPort = atmn.GetPort(pName)
  End If
End Function

Function GetImageDir()
  Dim imageDir
  ' Enter the directory where the image files are located
  WScript.StdOut.Write "Enter path to image files and flash programmer: "
  imageDir = WScript.StdIn.ReadLine
  ' Make sure the directory exists
  Set objFSO = CreateObject("Scripting.FileSystemObject")
  If objFSO.FolderExists(imageDir) Then
    ' If folder exists list all the image files we are going to load
    If ObjFSO.FileExists(imageDir & "\dbl.mbn") Then
      WScript.StdOut.Write "dbl.mbn" & vbCrLf
    End If
    If ObjFSO.FileExists(imageDir & "\osbl.mbn") Then
      WScript.StdOut.Write "osbl.mbn" & vbCrLf
    End If
    If ObjFSO.FileExists(imageDir & "\amss.mbn") Then
      WScript.StdOut.Write "amss.mbn" & vbCrLf
    End If
    If ObjFSO.FileExists(imageDir & "\apps.mbn") Then
      WScript.StdOut.Write "apps.mbn" & vbCrLf
    End If
    If objFSO.FileExists(imageDir & "\appsboot.mbn") Then
      WScript.StdOut.Write "appsboot.mbn" & vbCrLf
    End If
    If objFSO.FileExists(imageDir & "\flash.bin") Then
      WScript.StdOut.Write "flash.bin" & vbCrLf
    End If
    If objFSO.FileExists(imageDir & "\adsp.mbn") Then
      WScript.StdOut.Write "adsp.mbn" & vbCrLf
    End If
    GetImageDir = imageDir
  Else
    GetImageDir = ""
  End if

End Function
