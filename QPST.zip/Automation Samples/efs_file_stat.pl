###############################################################################
# (c) Qualcomm, Inc. 2006
#
# Demonstrate use of StatFile.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;
use efs_error;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "port $port_name\n";

    $port_status = $port->PhoneStatus;

    if ($phone_status_list{$port_status} eq "phoneStatusReady")
    {
      $efs = $port->EFS;

      if (defined $efs)
      {
        $version = $efs->EFSVersion;
        print "EFS version $version\n";

        if ($version == 2)
        {

          print "EFS path ? ";
          $efs_path = <STDIN>;
          chomp($efs_path);

          if ($efs_path ne "")
          {
            $mode  = Variant(VT_BSTR | VT_BYREF, "");
            $size  = Variant(VT_I4   | VT_BYREF, 0);
            $nlink = Variant(VT_I4   | VT_BYREF, 0);
            $atime = Variant(VT_BSTR | VT_BYREF, "");
            $mtime = Variant(VT_BSTR | VT_BYREF, "");
            $ctime = Variant(VT_BSTR | VT_BYREF, "");

            $efs->StatFile($efs_path, $mode, $size, $nlink, $atime, $mtime, $ctime);

            $error = 0 + Win32::OLE->LastError();

            if ($error == 0)
            {
              print "mode $mode\n";
              print "size $size\n";
              print "n link $nlink\n";
              print "a-time $atime\n";
              print "m-time $mtime\n";
              print "c-time $ctime\n";
            }
            else
            {
              print_error($error, $efs);
            }
          }
        }
        else
        {
          print "Incompatible EFS version\n";
        }
      }
      else
      {
        print "No EFS interface for this port\n";
      }

      undef $efs;
    }
    else
    {
      print "Phone not ready\n";
    }
  }
  else
  {
    print "Port not available\n";
  }

  undef $port;
}
else
{
  print "QPST not available\n";
}

undef $qpst;
